import logging
from datetime import datetime

from config import log_level

def setLogger(log_level=None):
	''' Initialize the logger with "DEBUG" level by default. Logs are created inside the logs folder. '''

	date_format = str(datetime.today().strftime('%Y_%m_%d'))
	logfile = 'logs/' + date_format + '.txt'

	log_format = '%(asctime)s %(levelname)s : %(message)s'

	logging.basicConfig(
        filename=logfile,
        level=logging.DEBUG,
        format=log_format,
        filemode="a"
    )

	return logging.getLogger()