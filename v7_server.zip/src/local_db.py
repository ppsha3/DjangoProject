'''
	Author: Priyesh Sharma
	Date: 20th April 2020
'''

from os import path
import mysql.connector

from config import local_db_info    # if this variable is not present an exception will be raised by the main file.
	

SRC_FILE = __file__.split(path.sep)[-1]

def updateQuery(query_id, exec_time):
	''' This function will be called if the query successfully ran. '''

	try:
		connection = mysql.connector.connect(**local_db_info)
		cursor = connection.cursor()
	except Exception as e:
		raise(f"From {SRC_FILE}: There was an exception in connecting to the local DB.\n" + str(e))
	else:
		try:
			cursor.execute('update query_details set last_run_time = ? where id = ?;', (exec_time, query_id))
			connection.commit()
		except Exception as e:
			raise Exception(f"From {SRC_FILE}: There was an error while saving the details. Please try again later.\n" + str(e))
		finally:
			connection.close()


def check_query():
	''' This will check for any scheduled query which is scheduled within the next hour. '''

	sch_queries = None

	try:
		connection = mysql.connector.connect(**local_db_info)
		cursor = connection.cursor()
	except Exception as e:
		raise Exception(f"From {SRC_FILE}: There was an error while connecting to the local DB.\n" + str(e))
	else:
		try:
			find_statement = '''SELECT q.id, q.query, q.server, q.recipients, u.name, q.last_run_time
								FROM query_details q, users u
								WHERE q.user_id = u.id
								AND q.isdeleted = 0
								AND q.frequency > q.current_run;
							'''
			# find_statement = '''SELECT q.id, q.query, q.server, q.recipients, u.name,
								# 	case when q.query_interval like '%%hour' then DATE_ADD(q.last_run_time, INTERVAL 0 hour) 
			 					# 		 when q.query_interval like '%%day' then DATE_ADD(q.last_run_time, INTERVAL 0 day)
             					# 		 when q.query_interval like '%%month' then DATE_ADD(q.last_run_time, INTERVAL 0 month) 
								# 	end as exec_time
								# FROM query_details q, users u
								# WHERE q.user_id = u.id
								# AND q.isdeleted = 0
								# AND q.frequency > q.current_run;
			# 				'''
			
			cursor.execute(find_statement)
		except Exception as e:
			raise Exception(f"From {SRC_FILE}: There was an error in checking for scheduled queue\n" + str(e))
		else:
			sch_queries = cursor.fetchall()
		finally:
			connection.close()

		return sch_queries