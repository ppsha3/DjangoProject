import mysql.connector
from os.path import sep
from threading import current_thread

SRC_FILE = __file__.split(sep)[-1]


def executeQuery(server_name, server_details, query, logger):
	'''
		This will execute query on the server.
		
		Accepts:
			server_name : Server's name in string. For ex - ATL1, DAL1, etc.
			server_details : a dict containing server info to connect DB
			query : string
			logger : logger object
		Returns:
			Result from the query
	'''

	thread_name = current_thread().getName()
	
	logger.info(f'From {SRC_FILE}: {thread_name} : Got Server Name: {server_name}')
	logger.info(f'From {SRC_FILE}: {thread_name} : Connecting to MySQL Server')

	try:
		connection = mysql.connector.connect(**server_details)
		cursor = connection.cursor()
	except Exception as e:
		logger.error(f"From {SRC_FILE}: There was an exception in connecting to the remote DB.\n" + str(e))
	else:
		try:
			logger.info(f'From {SRC_FILE}: {thread_name} : Connected! Executing query: "{query}""')
			cursor.execute(query)

		except Exception as e:
			logger.error(f'From {SRC_FILE}: {thread_name} : There was error in executing the query.' + str(e))
		
		else:
			logger.info(f'From {SRC_FILE}: {thread_name} : Query Executed! Fetching result.')
			return cursor.fetchall(), cursor.column_names

	return None, None