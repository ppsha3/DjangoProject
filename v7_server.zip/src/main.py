#!/usr/bin/env python3

'''
Author: Priyesh Sharma.
Email: priyesh.sharma@eclinicalworks.com

Version 7.0:
	1) Implemented Multi Thread
'''

from sys import exit
from os import path, mkdir, chmod
from datetime import datetime

try:
	import log_settings 		# Checking for necessary files/libraries.
	import report_handler
	import excel
	import config
	import local_db

	from mail import send_report
	from config import appl_path, remote_db_info

except Exception as e:

	stderr = path.join(path.abspath(path.dirname(__file__)), 'stderr.txt')

	with open(stderr, 'a+') as logfile:
		logfile.write(str(datetime.now()) + ': ' + str(e) + ' Ending Script...\n')

	exit(1)

else: 		#all imports was successful. Will check/create all the required folders now.

	LOGS_PATH = appl_path.get('LOGS_PATH', path.join(path.abspath(path.dirname(__file__)), 'logs', ''))

	if not path.isdir(LOGS_PATH):
		mkdir(LOGS_PATH)
		chmod(LOGS_PATH, 0o777)

	OUTPUT_PATH = appl_path.get('OUTPUT_PATH', path.join(path.abspath(path.dirname(__file__)), 'output', ''))

	if not path.isdir(OUTPUT_PATH):
		mkdir(OUTPUT_PATH)
		chmod(OUTPUT_PATH, 0o777)


def main():

	logger = log_settings.setLogger()         # initialize logger
	logger.info("Initial Check successful. Starting the Script...")

	try:
		sch_queries = local_db.check_query()      # check if there is any query (sch)eduled
		logger.info(f'Got {len(sch_queries)} queries to execute.')
	except Exception as e:
		logger.error(str(e) + '\n')
		exit(1)
	else:
		if not sch_queries:
			logger.info("No Queries found. Ending the script.\n")
			exit(0)

	for sch_query in sch_queries:

		report = report_handler.Report(sch_query)   # creating a report object for each sch_query

		logger.debug(f'Executing query id "{str(report.query_id)}" which is scheduled to run at "{report.exec_time}".')

		try:
			report.runReport(remote_db_info, logger)    # getting db info from the global config file
		except Exception as e:
			logger.error(str(e))
			report.alert_msg.append(str(e))
		else:
			# creating a temp file in memory. The file will only be saved to the disk if data is written.
			filename = 'output/query' + str(report.query_id) + datetime.now().strftime('_%Y_%m_%d_%H_%M') + '.xlsx'

			try:
				excel_book = excel.excel(filename)
				excel_book.add(*report.getResult())    	# get the result and write it to the excel file
				logger.info('Temp file created. Writing data to temp file.')

			except TypeError as e:
				logger.error("Did not get any result from the query. Skipping this query.")
				report.alert_msg.append(str(e))
			
			except Exception as e:
				logger.error(str(e))
				report.alert_msg.append(str(e))
			
			else:
				excel_book.save()
				logger.info(f'Data successfully written. File "{filename}" created.')

				logger.info(f'Updating information in local DB.')

				try:
					local_db.updateQuery(report.query_id, report.exec_time)
					logger.info(f"'Query {report.query_id}' last run time updated.")
				except Exception as e:
					logger.error(str(e))
					report.alert_msg.append(str(e))	

				try:
					logger.info('Sending the file to : ' + str(report.recipients))	
					# send_report(report.recipients, filename)
					logger.info("The result was successfully sent via mail.")
				except Exception as e:
					logger.error('Could not send the file to recipients. Please send it manually.' + str(e))
 
		if report.alert_msg:   		# If this is not empty an alert will be send to admin.
			try:
				# report.send_alert()
				logger.info("An alert has been sent to the admin team.")
			except:
				logger.error("There was an error in raising the alert.")

		logger.info(f'Completed "Query ID {str(report.query_id)}" with {len(report.alert_msg)} error/s.')


if __name__ == '__main__':
	main()