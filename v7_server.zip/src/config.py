from os import path

appl_path = {

	'LOGS_PATH' : path.join(path.abspath(path.dirname(__file__)), 'logs', ''),
	'OUTPUT_PATH' : path.join(path.abspath(path.dirname(__file__)), 'output', ''),	
}

log_level = { 'level' : 'DEBUG' }

remote_db_info = {

	'mydb' : {
	
		'user': 'root',
		'password': 'root',
		'host': 'localhost',
		'database': 'mydb',
		'port': '3306',
		'raise_on_warnings': True,
		'auth_plugin' : 'mysql_native_password'
	},

	'mydb2' : {
	
		'user': 'root',
		'password': 'root',
		'host': 'localhost',
		'database': 'mydb2',
		'port': '3306',
		'raise_on_warnings': True,
		'auth_plugin' : 'mysql_native_password'
	}
	
}

local_db_info = {

	'user': 'root',
	'password': 'root',
	'host': 'localhost',
	'database': 'mydb',
	'port': '3308',
	'raise_on_warnings': True,
	'auth_plugin' : 'mysql_native_password'

}

mail_settings = {

	'admin_email' : 'atlantis-tm@eclinicalworks.com',
	'from address' : 'ppsha100@gmail.com',
	'from password' : '',
	'port' : 465

}

