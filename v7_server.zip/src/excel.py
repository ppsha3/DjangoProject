import xlsxwriter as xlsx

class excel():
	'''
		wrapper for the xlsxwriter library.
		Accepts:
			name -> the path of the file.
	'''

	def __init__(self, name):
	
		self.name = name
		self.current_row = 0
		self.current_column = 0
		self.workbook = xlsx.Workbook(name)
		self.worksheet = self.workbook.add_worksheet()
		self.is_empty = True
		self.header = False
		
	def add(self, result, columns):
		''' Accepts:
				result -> A list containing tuples of the resulting data
				columns -> A list containing column names from the data.
		''' 

		try:
			if not self.header:
				for column in columns:
					self.worksheet.write(self.current_row, self.current_column, str(column))
					self.current_column += 1
				self.current_row += 1
				self.current_column = 0
							
				self.header = True

			for row in result:
				for cell in row:
					self.worksheet.write(self.current_row, self.current_column, str(cell))
					self.current_column += 1
				self.current_row += 1
				self.current_column = 0

		except:
			raise
		
		else:		
			self.is_empty = False
		
	def save(self):
		''' Will write the data to the disk. ''' 
	
		self.workbook.close()
	
