import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from zipfile import ZipFile
from os.path import sep

import config

SRC_FILE = __file__.split(sep)[-1]


def archive_file(filename):
    '''Compress the xlsx file to zip for sending email.'''

    zip_path = filename.replace('.xlsx', '.zip')
    
    with ZipFile(zip_path, 'w') as zip_file:
        zip_file.write(filename)
    
    return zip_path


def send_mail(to_address, subject, msg, attachment=None):
    ''' Basic function to send an email with optional attachment. '''

    port = config.mail['port']
    from_address = config.mail['from_address']
    from_password = config.mail['from_password']

    message = MIMEMultipart()   # initialize a MIME message
    message['From'] = from_address
    message['To'] = to_address
    message['Subject'] = subject
    message.attach(MIMEText(msg, 'plain'))
    
    if attachment:
        message.attach(attachment)

    with smtplib.SMTP_SSL("smtp.gmail.com", port) as server:
        server.login(from_address, from_password)
        # server.sendmail(email_address, recipients, message.as_string())
        server.sendmail(from_address, from_address, message.as_string())        # will keep just for demo purpose


def send_report(recipients, filename):
    ''' Compress the xlsx file to zip for sending email. '''
    
    try:
        zip_file = archive_file(filename)
    except Exception as e:
        raise Exception(f"From {SRC_FILE}: There was an error in zipping the file content.\n" + str(e))
    else:
        subject = '*SECURE* Your Messenger Report is ready.'

        msg = ''' Hello, 
        This is an auto-generated email. Your messenger report is ready. 
        Please check the attached file. If you find any issues, please contact SM team.

        Thank You.
        '''

        try:    #create the attachment
            with open(zip_file, 'rb') as attachment:           # Open the file as binary mode
                payload = MIMEBase('application', 'octate-stream')
                payload.set_payload(attachment.read(), charset='UTF-8')
                encoders.encode_base64(payload)
                payload.add_header('Content-Disposition', 'attachment', filename='result.zip')   # Set the filename to be displayed
        except Exception as e:
            raise Exception(f"From {SRC_FILE}: There was in attaching the file.\n" + str(e))
        else:
            try:
                send_mail(to_address=recipients, msg=msg, attachment=payload, subject=subject)
            except Exception as e:
                raise Exception(f"From {SRC_FILE}: There was an error in sending the email.\n" + str(e))
