# for each sch query:

# extract details
# create threads
# get thread result
# write to file
# send file
# update query details

# repeat

from os.path import sep

import thread_handler
import remote_db
from config import mail_settings
from mail import send_mail

SRC_FILE = __file__.split(sep)[-1]

class Report():

	def __init__(self, sch_query):

		self.query_id = sch_query[0]
		self.query = sch_query[1]
		self.server_list = sch_query[2].split(' ')
		self.recipients = sch_query[3].split(' ')
		self.user_name = sch_query[4]
		self.exec_time = sch_query[5]

		self.alert_msg = []    # for storing alert msgs. If this is not empty an alert will be send to admin.

	def runReport(self, server_info, logger):
		''' Will create a separate thread for each server and run the query on them '''

		self.thread_list = []

		for i in range(len(self.server_list)):         # this loop will create thread objects
			try:
				server_name = self.server_list[i]
				server_details = server_info[server_name]
			except Exception as e:
				raise Exception(f'From {SRC_FILE}: Could not get server details. Incorrect server name "{server_name}".\n' + str(e))
			else:
				try:
					thread = thread_handler.myThread (
						name='Thread '+ str(i), 
						target=remote_db.executeQuery,
						args=(server_name, server_details, self.query, logger)
					)
					thread.start()
				except Exception as e:
					raise Exception(f"From {SRC_FILE}: Failed to start the thread\n" + str(e))
				else:
					self.thread_list.append(thread)

	def getResult(self):
		''' Will get result from each thread and chain them into a list '''

		result_list = []   # to store results from individual threads

		for thread in self.thread_list:
			result, columns = thread.syncResults()    # getting the result from each thread
			if result and columns:          
				result_list.append(result)    # creating a single list

		return result, columns

	def send_alert(self):
		'''Function to send an alert. This will only be called if alert_msg is not blank.'''

		subject = 'Error while running the query.'

		msg = f'''There was an error while executing {self.query_id} scheduled by {self.user_name}.
				The query exited with the message: \n{self.alert_msg}\nPlease have a look as soon as possible.'''

		try:
			send_mail(to_address=mail_settings['admin_email'], msg=msg, subject=subject)
		except Exception as e:
			raise Exception(f"From {SRC_FILE}: There was an error in sending the email.\n" + str(e))
