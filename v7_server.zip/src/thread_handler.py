from threading import Thread

class myThread(Thread):
	''' Overriding the thread class to store the results from each threads. '''

	def __init__(self, name, target, args):
		super().__init__(name=name, target=target, args=args, group=None)

	def run(self):
		''' This will run the thread and store results from each thread. '''

		if self._target:
			self._result, self._columns = self._target(*self._args)

	def syncResults(self):
		''' Will wait for each thread to finish and then return the results to avoid out of order results. '''

		self.join()   # waits till all the other threads finish execution.

		return self._result, self._columns