from django.urls import path

from . import views

urlpatterns = [
    path('', views.index, name='index'),
	path('update/<int:query_id>/', views.update, name='update'),
	path('delete/<int:query_id>/', views.delete, name='delete'),
	path('add/', views.add, name='add'),
	path('users/', views.users, name='users'),
	path('createUser/', views.createUser, name='createUser'),
	path('updateUser/<int:user_id>', views.updateUser, name='updateUser'),
	path('deleteUser/<int:user_id>', views.deleteUser, name='deleteUser'),
	path('login/', views.login, name='login'),
	path('logout/', views.logout, name='logout'),
	path('view/<int:query_id>/', views.view, name='view')
]