from django.db import models

## Django created models file based on the existing database.

class QueryDetails(models.Model):
	query = models.CharField(max_length=1024)
	server = models.CharField(max_length=255)
	recipients = models.CharField(max_length=1024)
	last_run_time = models.DateTimeField()
	query_interval = models.CharField(max_length=45)
	user = models.ForeignKey('Users', models.DO_NOTHING)
	datecreated = models.DateTimeField()
	isdeleted = models.IntegerField()
	last_run_result = models.IntegerField()
	frequency = models.IntegerField()
	current_run = models.IntegerField()
	title = models.CharField(max_length=75)

	def __str__(self):
		return self.title
	
	class Meta:
		managed = False
		db_table = 'query_details'


class Users(models.Model):
	name = models.CharField(max_length=45)
	email = models.CharField(max_length=128)
	isdeleted = models.IntegerField()
	
	def __str__(self):
		return self.name
		
	class Meta:
		managed = False
		db_table = 'users'
