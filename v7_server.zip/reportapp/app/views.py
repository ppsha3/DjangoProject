from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import QueryDetails
from .models import Users

#####
## Messenger Queries
#####

def index(request):

	# How to:
	# 1) get a list of all queries scheduled by the user.
	# 2) Return a list
	# 3) 

	template = loader.get_template('index.html')

	active_queries = QueryDetails.objects.all().filter(isdeleted=0)
	inactive_queries = QueryDetails.objects.all().filter(isdeleted=1)
	
	context = {
        'active_queries': active_queries,
		'inactive_queries': inactive_queries
	}
	
	return HttpResponse(template.render(context), request)

def update(request, query_id):

	return HttpResponse(" Update Scheduled Queries ")

def view(request, query_id):

	template = loader.get_template('view-query.html')

	query = QueryDetails.objects.all().filter(id=query_id)

	context = {
        'query': query,
	}

	return HttpResponse(template.render(context), request)

def delete(request, query_id):

	return HttpResponse(" Delete Scheduled Queries ")

def add(request):

	template = loader.get_template('add-query.html')

	# QueryDetails.objects.create()

	return HttpResponse(template.render())

#####
## Users table
#####

def users(request):

	template = loader.get_template('users.html')

	return HttpResponse(template.render())

def updateUser(request, user_id):

	return HttpResponse("Update User")

def deleteUser(request, user_id):

	return HttpResponse("Delete User")

def createUser(request):

	template = loader.get_template('add-user.html')

	# QueryDetails.objects.create()

	return HttpResponse(template.render())

#####
## Login and Logout
#####

def login(request):

	template = loader.get_template('login.html')

	return HttpResponse(template.render())

def logout(request):

	template = loader.get_template('logout.html')

	return HttpResponse(template.render())