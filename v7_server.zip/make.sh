#! /bin/bash

### File Info ###
# Author: Priyesh Sharma
# Date: 23rd April 2020
###

### About ###
# This script will download/install all the dependencies required for report automation script/service and initialize them with project defaults.
# Explicitly, two environmental changes will be made.
#   1) Installing Mysql 
#   2) Installin Python
###

### Requirments ###
# This script requires: 
#      1) a requirements.txt file containing all required python lib
#      2) root login
###

### How to ###
# 1) Login as root
# 2) change to the project's util directory
# 3) Run this file using ./make
# 4) Sit back and relax.


## Check for mysql service ##

get_service_status(){

  ## The function will return the status of the mysql service sent as an argument. If the service is inactice. It will attempt to start it. ##

  search_result=$(systemctl list-units mysqld.service --all --type service --full --no-legend)

  if [[ ${search_result} == '' ]]; then
    return 1        # did not find anything
  elif [[ $(echo "${search_result}" | cut -f3 -d' ') == "active" ]]; then
    return 0        # found the service in active mode
  else
    echo "The service is in inactive mode. Attempting to start the service."
    systemctl start mysqld.service    # the service is in inactive mode
    if [[ ${?} == 0 ]]; then
        echo "The service was started."
        return 0
    else
        echo "There was an error in starting the service."
        return 2
    fi
  fi

}

install_mysql(){

    ## Function will download the service after adding the repo in the default mirror. ##
    
    local filename="mysql80-community-release-el7-3.noarch.rpm"
    local url="https://dev.mysql.com/get/${filename}" "${filename}"
    
    # download the repo from offical website, add it to the default mirror and then installing the mysql service using system defaults
    wget ${url} &&  rpm -ivh ${filename} && yum install -y mysql-server && echo "The service was successfully installed." || echo "Could not install the service"
    
    return ${?}

}

initialize_mysql(){

    return 0

}

check_mysql_service(){

    get_service_status   # the service can be be installed and inactive OR installed and active OR 

    retval=${?}

    if [[ ${retval} == 1 ]]; then    # not installed. Therefore, installing the service
    
        echo -e "The service was not found.\nDownloading and installing the service now."
        install_mysql && echo "The service was successfully installed." || echo "The service could not be installed." && return 1
        
        initialize_mysql && echo "MySQL database was successfully initialized" && return 0 \
        || echo "There was an error in initializing MySQL database" && return 1
    
    elif [[ ${retval} == 2 ]]; then    # installed and inactive and refusing to start
    
        return 1    
    
    else          # installed and active
    
        echo -e "The service is running.\nNothing to do." && return 0

    fi

}


## Check for python installation ##


install_python(){

    return 0

}



check_python(){

    return 0

}


echo "Checking for mysqld service..."
check_mysql_service
echo "Checking for python..."
check_python



























